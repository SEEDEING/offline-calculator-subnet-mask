﻿import ipaddress

# 函数：根据 IP 第一段自动识别 Class
def get_class(ip: str) -> str:
    first_octet = int(ip.split(".")[0])
    if 0 <= first_octet <= 127:
        return "A"
    elif 128 <= first_octet <= 191:
        return "B"
    elif 192 <= first_octet <= 223:
        return "C"
    elif 224 <= first_octet <= 239:
        return "D (组播)"
    elif 240 <= first_octet <= 255:
        return "E (保留)"
    else:
        return "未知"

# 函数：计算子网信息，并返回字典
def subnet_info(ip: str, prefix: int) -> dict:
    network = ipaddress.ip_network(f"{ip}/{prefix}", strict=False)
    ip_class = get_class(ip)

    info = {
        "Class": ip_class,
        "IP Type": "Private" if network.is_private else "Public",
        "IP Address": str(network.network_address),
        "Network Address": str(network.network_address),
        "Broadcast Address": str(network.broadcast_address),
        "Wildcard Mask": str(network.hostmask),
        "Subnet Mask": str(network.netmask),
        "Binary Subnet Mask": '.'.join(f'{octet:08b}' for octet in network.netmask.packed),
        "CIDR Notation:": '/'+ str(prefix),
        "Total Hosts": network.num_addresses,
        "Usable Hosts": network.num_addresses - (2 if network.prefixlen < 31 else 0),
    }

    # 计算可用主机范围
    if prefix < 31:
        info["Host Range"] = f"{network[1]} - {network[-2]}"
    else:
        info["Host Range"] = "N/A"

    return info


if __name__ == "__main__":
    # 用户输入 IP 与前缀
    ip = input("Enter IP address (e.g. 192.168.1.0): ")
    prefix = int(input("Enter CIDR prefix length (e.g. /25): "))

    result = subnet_info(ip, prefix)

    # 打印子网详细信息
    print("\n--- All Subnet Calculation Result ---")
    for k, v in result.items():
        print(f"{k}: {v}")

    # 找出父网段（依据 Class A/B/C）
    network = ipaddress.ip_network(f"{ip}/{prefix}", strict=False)
    supernet = network.supernet(new_prefix=8) if result["Class"] == "A" else (
        network.supernet(new_prefix=16) if result["Class"] == "B" else (
            network.supernet(new_prefix=24) if result["Class"] == "C" else network))

    # 获取所有可能的同级子网
    subnets = list(supernet.subnets(new_prefix=prefix))
     
    # 打印子网表格
    print("\n--- Subnet Calculation Table ---")
    print(f"\nTabel {len(subnets)} of the /{prefix} Networks for {supernet.network_address}.*\n")

    print("-" * 81)
    print("|{:<16}|{:<33}|{:<23}|".format("Network Address", "Usable Host Range", "Broadcast Address"))
    print("|" + "-" * 79 + "|")

    for subnet in subnets:
        if subnet.prefixlen < 31:
            host_range = f"{subnet[1]} - {subnet[-2]}"
        else:
            host_range = "N/A"
        print("|{:<16}|{:<33}|{:<23}|".format(
            str(subnet.network_address),
            host_range,
            str(subnet.broadcast_address)
        ))

    print("-" * 81)
